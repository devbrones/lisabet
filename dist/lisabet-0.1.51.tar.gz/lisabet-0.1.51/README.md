# Lisabet
## Stenography training application


Check ```./dist/``` for beta wheels
